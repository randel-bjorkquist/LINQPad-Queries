﻿namespace mcsCore.Services.FeatureFlag;

public readonly struct FeatureFlagResolution
{
    public FeatureFlagResolution(string? featureFlag, int tenantId, FeatureFlagValueSource source, int priority, bool value)
    {
        FeatureFlag = featureFlag;
        TenantID    = tenantId;
        Source      = source;
        Priority    = priority;
        Value       = value;
    }

    public string? FeatureFlag            { get; } = string.Empty;
    public int TenantID                   { get; }
    public FeatureFlagValueSource Source  { get; }
    public int Priority                   { get; }
    public bool Value                     { get; }
}
