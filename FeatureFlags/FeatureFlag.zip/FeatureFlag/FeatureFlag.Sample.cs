﻿using mcsCore.Utilities.Common.TypedEnums.Base;
using System;

namespace mcsCore.Services.FeatureFlag;

public sealed partial class FeatureFlag : TypedEnumGuid<FeatureFlag>
{
    #region specific FeatureFlag definitions ...
    
    //NOTE: these are all currently madeup and thus, NOT REAL Feature Flags ...

    public static readonly FeatureFlag ExpirableFile         = new(Guid.Parse("6255cf3c-2a18-4082-87f0-764bf76cc0f9") ,"Expirable File"          ,nameof(ExpirableFile));    
    public static readonly FeatureFlag ExpirableFile_Create  = new(Guid.Parse("c473d35a-c391-444b-86a7-4aac8319db4e") ,"Expirable File - create" ,nameof(ExpirableFile_Create));
    public static readonly FeatureFlag ExpirableFile_Update  = new(Guid.Parse("c74e06d8-1b6d-4614-8218-facb10da1ca6") ,"Expirable File - update" ,nameof(ExpirableFile_Update));
    public static readonly FeatureFlag ExpirableFile_Delete  = new(Guid.Parse("aeba8047-b728-4e5b-8d66-f74f44a4bc76") ,"Expirable File - delete" ,nameof(ExpirableFile_Delete));

    #endregion
}
