﻿namespace mcsCore.Services.FeatureFlag;

public enum FeatureFlagValueSource
{
    Default,
    Global,
    Tenant
}
