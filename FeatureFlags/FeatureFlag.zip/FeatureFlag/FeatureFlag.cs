﻿using mcsCore.Utilities.Common.TypedEnums.Base;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading;

namespace mcsCore.Services.FeatureFlag;

public sealed partial class FeatureFlag : TypedEnumGuid<FeatureFlag>
{
    private readonly bool _IsActiveDefault;
    private static bool IsInitialized => _configPath is not null;
    
    public bool IsActive => GetIsActiveValue();  

    private FeatureFlag(Guid id, string description, string code, bool active = false)
      : base(id, description, code)
    {
        _IsActiveDefault = active;  //initial value
    }

    public override string ToString()
      => base.ToString("C");
  
    // FeatureFlag -> bool (implicit or explicit)
    [Obsolete("Prefer FeatureFlag.Field.IsActive for clarity and future-proofing.", false)]
    public static implicit operator bool(FeatureFlag flag)
    {
        EnsureInitialized();
        return flag.IsActive;
    }
  
    /// <summary>
    /// Gets whether this feature flag is active for the specified tenant.
    /// Uses tenant-specific override if present, otherwise falls back to global/default.
    /// Use <c>null</c> or empty string for global/default value.
    /// </summary>
    /// <param name="tenantId">The tenant ID or null/empty for global.</param>
    /// <returns>true if the flag is active for the tenant (or globally), false otherwise.</returns>  
    public bool this[string? tenantId]
    {
        get
        {
            if(string.IsNullOrWhiteSpace(tenantId))
                return IsActive;
            
            return GetTenantValue(tenantId!);
        }
    }
  
    /// <summary>
    /// Gets whether this feature flag is active for the specified tenant.
    /// Uses tenant-specific override if present, otherwise falls back to global/default.
    /// Use <c>null</c> or empty string for global/default value.
    /// </summary>
    /// <param name="tenantId">The tenant ID or 0 (zero) for global.</param>
    /// <returns>true if the flag is active for the tenant (or globally), false otherwise.</returns>  
    public bool this[int tenantId]
    {
        get
        {
            if(tenantId <= 0)
                return IsActive;
            
            return GetTenantValue(tenantId.ToString());
        }
    }
  
    private bool GetIsActiveValue()
    {
        EnsureInitialized();

        var config = _configCache;
        
        if(config is not null && 
           config.Global.TryGetValue(Code, out bool globalValue))
        {
            return globalValue;
        }
        
        return _IsActiveDefault;
    }
  
    private bool GetTenantValue(string tenantId)
    {        
        EnsureInitialized();
        
        var config = _configCache;
        
        if(config is null)
            return IsActive;
        
        if(config.Tenants.TryGetValue(tenantId, out var tenantFlags) &&
           tenantFlags.TryGetValue(Code, out bool tenantValue))
        {
            return tenantValue;
        }
        
        return IsActive;
    }
    
    public List<FeatureFlagResolution> Resolve(string? tenantId)
      => int.TryParse(tenantId, out var id) ? Resolve(id) 
                                            : Resolve();
    
    public List<FeatureFlagResolution> Resolve(int tenantId = 0)
    {
        var priority = 0;
        var results  = new List<FeatureFlagResolution>();

        EnsureInitialized();
        var config = _configCache;
        
        // tenant ...
        if(tenantId > 0                                                         &&
           config is not null                                                   &&
           config.Tenants.TryGetValue(tenantId.ToString(), out var tenantFlags) &&
           tenantFlags.TryGetValue(Code, out bool tenantValue))
        {
            priority = 1;
            results.Add(new FeatureFlagResolution(Description, 
                                                  tenantId, 
                                                  FeatureFlagValueSource.Tenant, 
                                                  priority, 
                                                  tenantValue));
        }    
        
        // global ...
        if(config is not null &&
           config.Global.TryGetValue(Code, out bool globalValue))
        {
            priority = results.Any() ? 2 : 1;
            results.Add(new FeatureFlagResolution(Description, 
                                                  tenantId, 
                                                  FeatureFlagValueSource.Global, 
                                                  priority, 
                                                  globalValue));
        }

        // default ...
        priority = results.Any() ? (results.Count() == 2 ? 3 : 2) : 1;
        results.Add(new FeatureFlagResolution(Description, 
                                              tenantId, 
                                              FeatureFlagValueSource.Default, 
                                              priority, 
                                              _IsActiveDefault));

        return results;
    }
    
    #region internal service & auto-updating ...
    
    // Config File Variable(s)
    private static volatile FeatureFlagConfig? _configCache;
    private static readonly object _configLock = new();
    private static volatile string? _configPath;
    
    // Watcher Variable(s)
    private static FileSystemWatcher? _watcher;
    private static int _watcherDisposed; // 0 = active, 1 = disposed
    private static DateTime _lastLoaded = DateTime.MinValue;
    private const int DEBOUNCE_MS = 150;
    
    // PollTimer Variable(s)
    private const int POLL_MS = 1000; // 1s is plenty for local dev; 2s is also fine
    private static Timer? _pollTimer;
    
    private static long _lastLength = -1;
    private static DateTime _lastWriteUtc = DateTime.MinValue;
    
    /// <summary>
    /// Must be called once at application startup (or lazily on first use) ...
    /// It can be put call in the 'global.asax' page OR both methods with implicit operators ...
    /// </summary>
    public static void Initialize(string configFileName = "FeatureFlags.json", bool enableAutoReload = true)
    {
        string configFilePath = ConfigurationManager.AppSettings["FeatureFlagConfigPath"];
        
        if(_configPath is not null)
            return;
        
        lock(_configLock)
        {
            if(_configPath is not null)
                return;
            
            Volatile.Write(ref _watcherDisposed, 0);
            
            _configPath = Path.Combine(configFilePath, configFileName);
            LoadConfiguration();
            
            if(enableAutoReload)
            {
                CreateWatcher();
                StartPolling();
            }
        }
    }
    
    private static void EnsureInitialized()
    {
        if(IsInitialized) 
            return;
        
        Initialize();
    }
    
    private static void CreateWatcher()
    {
        if(string.IsNullOrWhiteSpace(_configPath))
            return;
        
        var directory = Path.GetDirectoryName(_configPath);
        
        if(string.IsNullOrEmpty(directory))
            return;
        
        _watcher?.Dispose();
        
        _watcher = new FileSystemWatcher(directory) { Filter = Path.GetFileName(_configPath),
                                                      NotifyFilter = NotifyFilters.LastWrite  |
                                                                     NotifyFilters.FileName   |
                                                                     NotifyFilters.Size       |
                                                                     NotifyFilters.CreationTime,
                                                      EnableRaisingEvents   = true,
                                                      InternalBufferSize    = 64 * 1024,  // max 64KB
                                                      IncludeSubdirectories = false };
        
        _watcher.Changed += OnConfigFileChanged;
        _watcher.Created += OnConfigFileChanged;
        _watcher.Deleted += OnConfigFileChanged;
        
        _watcher.Renamed += OnConfigFileRenamed;
        _watcher.Error   += OnWatcherError;
    }

    private static void LoadConfiguration()
    {
        if(_configPath == null || !File.Exists(_configPath))
        {
            lock(_configLock)
            {
              _configCache = new FeatureFlagConfig(); // empty -> defaults apply
            }
            
            return;
        }

        string json = string.Empty;
        
        try
        {
            using var fs = new FileStream(_configPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            using var sr = new StreamReader(fs);
            
            json = sr.ReadToEnd();
        }
        catch { return; }

        FeatureFlagConfig? newConfig = null;

        try
        {
            var options = new JsonSerializerOptions () { PropertyNameCaseInsensitive = true,
                                                         WriteIndented               = true };
            
            newConfig = JsonSerializer.Deserialize<FeatureFlagConfig>(json, options);
            
            if(newConfig is null)
                return;
        }
        catch { return; }
    
        lock(_configLock)
        {
            _configCache = newConfig;
        }
    }
    
    private static void DebouncedReload()
    {
        var now = DateTime.UtcNow;
        
        if((now - _lastLoaded).TotalMilliseconds < DEBOUNCE_MS)
          return;
    
        lock(_configLock)
        {
            if((now - _lastLoaded).TotalMilliseconds < DEBOUNCE_MS)
                return;
            
            LoadConfiguration();
            _lastLoaded = now;
        }
    }
    
    private static void OnConfigFileChanged(object? sender, FileSystemEventArgs e)
    {
        if(Volatile.Read(ref _watcherDisposed) == 1)
            return;
        
        DebouncedReload();
    }
    
    private static void OnConfigFileRenamed(object? sender, RenamedEventArgs e)
    {
        if(Volatile.Read(ref _watcherDisposed) == 1)
            return;

        DebouncedReload();
    }
    
    private static void OnWatcherError(object? sender, ErrorEventArgs e)
    {
        if(Volatile.Read(ref _watcherDisposed) == 1) 
            return;
        
        lock(_configLock)
        {
            if(Volatile.Read(ref _watcherDisposed) == 1) 
                return;
        
            if(_watcher is not null)
            {
                _watcher.EnableRaisingEvents = false;
                _watcher.Dispose();
                _watcher = null;
            }

            // recreate watcher using existing _configPath
            CreateWatcher();              
        }
        
        // trigger a reload attempt as a "best effort"
        DebouncedReload();
    }
    
    private static void StartPolling()
    {
        // Start once
        if(_pollTimer is not null)
            return;
        
        // Timer callbase should never throw
        _pollTimer = new Timer(_ => {
            try
            {
                if(Volatile.Read(ref _watcherDisposed) == 1)
                    return;
                
                var path = _configPath;

                if(string.IsNullOrWhiteSpace(path))
                    return;
                
                // If the file is missing, we can optionally reload to "empty config"
                if(!File.Exists(path))
                {
                    //Only reload if we previously had a file
                    if(_lastWriteUtc != DateTime.MinValue || _lastLength != -1)
                    {
                        _lastWriteUtc = DateTime.MinValue;
                        _lastLength   = -1;
                        
                        DebouncedReload();
                    }
                    
                    return;
                }
                
                // Stat the file. This is cheap and avoids reading/parsing ever second.
                var info      = new FileInfo(path);
                var writeUtc  = info.LastWriteTimeUtc;
                var length    = info.Length;
                
                // If neither timestamp nor length changed, do nothing.
                // (Length catches some edge cases; timestamp usually changes even for small edits.)
                if(writeUtc == _lastWriteUtc && length == _lastLength)
                    return;

                _lastWriteUtc = writeUtc;
                _lastLength   = length;

                // Triggers the same reload we already trust
                DebouncedReload();
            }
            catch { /* swallow - polling is a best-effort safety net */ }
        }, 
        state: null, 
        dueTime: POLL_MS, 
        period: POLL_MS);
    }
    
    public static void DisposeWatcher()
    {
        //Get first: any late callbacks become no-ops
        Volatile.Write(ref _watcherDisposed, 1);

        lock(_configLock)
        {
            // Watcher cleanup ...
            if(_watcher is not null)
            {
                _watcher.EnableRaisingEvents = false;
                
                _watcher.Changed -= OnConfigFileChanged;
                _watcher.Created -= OnConfigFileChanged;
                _watcher.Deleted -= OnConfigFileChanged;
                _watcher.Renamed -= OnConfigFileRenamed;
                _watcher.Error   -= OnWatcherError; ;
            
                _watcher.Dispose();
                _watcher = null;
            }
            
            // Polling timer cleanup ...
            if(_pollTimer is not null)
            {
                _pollTimer.Dispose();
                _pollTimer = null;
            }
        }
    }

    #endregion
}
