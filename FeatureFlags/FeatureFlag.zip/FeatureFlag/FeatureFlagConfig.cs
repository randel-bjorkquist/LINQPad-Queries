﻿using System.Collections.Generic;

namespace mcsCore.Services.FeatureFlag;

public class FeatureFlagConfig
{
    public Dictionary<string, bool> Global                        { get; set; } = [];
    public Dictionary<string, Dictionary<string, bool>> Tenants   { get; set; } = [];
}
